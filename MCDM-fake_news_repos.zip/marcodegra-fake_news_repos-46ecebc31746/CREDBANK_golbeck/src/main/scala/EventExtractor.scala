/**
 * Created by cbuntain on 2/1/16.
 */
object EventExtractor {

}
