import tweepy
import json
import pandas as pd

CONSUMER_KEY = 'nyIMoX0KIzJNlgVTD6GLSFKAp'
CONSUMER_SECRET = '8sseu3QNcPUooS8vrICRduICAPrEO56g64FzYrQuUm5VZYG05D'
OAUTH_TOKEN = '354231454-7pjsPJxUzvTHY9kHQUedkhCbwMLfWEPveGJbU6qQ'
OAUTH_TOKEN_SECRET = 'Wmq0oeDRjBgzu69P1k80PUQMlArK5VfO4D0eloTBfRHGy'

auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(OAUTH_TOKEN, OAUTH_TOKEN_SECRET)
api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True)

tweets_IDs_file = 'data/tweetsRatings.json'

#print(api.get_status(522577018655764480))
#print(api.statuses_lookup([522701337541492736, 522577018655764480]))


with open(tweets_IDs_file, "r") as f:
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f)
    next(f) #23
    #eventIndex = 2
    for events, line in enumerate(f):
        print('Line:', events)
        jsonData = json.loads(line)
        #eventIndex += 1
        event_filename = jsonData['key']
        features_file = 'data/credbank_features.json'
        df = pd.read_json(features_file, orient='index')
        #print(df.index)
        #quit()
        if (event_filename in df.index):
            tweetIDs_list = jsonData['tweets']
            # Split the tweetIDs_list into chunks each of 100 IDs to respect the api limit
            chunks = [tweetIDs_list[x:x + 100] for x in range(0, len(tweetIDs_list), 100)]
            #print(len(chunks))
            #print(chunks[3][100])
            #print(len(chunks[346]))
            for i in range(len(chunks)-1):
                for j in range(len(chunks[i])-1):
                    try:
                        print('chunk n. =', i, 'id n. =', j)
                        single_tweetJSON = api.get_status(chunks[i][j])
                        print(single_tweetJSON, file=open("../CREDBANK_golbeck/src/main/python/Labeling/singleFileEventData/"
                                                          "%s.json.gz" % event_filename, "a", encoding="utf-8"))
                        print('ok')
                    except tweepy.error.TweepError:
                        print("TWEET NOT AVAILABLE!")
                        pass
                    except IndexError:
                        pass





# >>> Tweet 0: 1006 tweets on 1376 successfully retrieved
#>>>  Tweet 1: 799 tweets on 1047 (print("Tweet", tweetID, "of event n.", events,
#                                  api.get_status(jsonData["tweets"][tweetID]))
#                                  IndexError: list index out of range) successfully retrieved
# >>> Tweet 2: 749 tweets on 1046 successfully retrieved
# >>> Tweet 3: 764 tweets on 1019 successfully retrieved
# >>> Tweet 4: 747 tweets on 1018 successfully retrieved

# TOTAL: 4065 on 5506 (73.8%)

