import sklearn.linear_model
import sklearn.ensemble
import matplotlib.pyplot as plt
from sklearn.metrics import *
import numpy as np

def metrics_calc(label, prediction):

    fpr, tpr, thresholds = roc_curve(label, prediction)
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, lw=1, label='ROC (area = %0.2f)' % (roc_auc))

    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Luck')

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.grid()
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")

    plt.savefig("data/rocauc.pdf", format="pdf")
    plt.show()

    # print('tpr', tpr, 'fpr', fpr, 'thresholds', thresholds)
    optimal_idx = np.argmax(tpr - fpr)
    optimal_threshold = thresholds[optimal_idx]
    print('Optimal ROC-AUC threshold:', round(optimal_threshold, 4))

    #j_scores = tpr - fpr
    #j_ordered = sorted(zip(j_scores, thresholds))
    #print('Optimal ROC-AUC threshold:', j_ordered[-1][1])

    # Create a binary prediction vector based on OWA optimal threshold
    prediction_label = []
    for i in range(len(prediction)):
        if (prediction[i] >= optimal_threshold):
            prediction_label.append(1)
        else:
            prediction_label.append(0)

    accuracy = accuracy_score(label, prediction_label)
    precision = precision_score(label, prediction_label)
    recall = recall_score(label, prediction_label)
    f1 = f1_score(label, prediction_label)

    #confusion_matrix = sklearn.metrics.confusion_matrix(label, prediction_label)
    #print('\nTP:', confusion_matrix[1][1], 'TN:', confusion_matrix[0][0],
         # '\nFP:', confusion_matrix[0][1], 'FN:', confusion_matrix[1][0])

    print('\nACCURACY:', round(accuracy, 2))
    print('PRECISION:', round(precision, 2))
    print('RECALL:', round(recall, 2))
    print('F1-SCORE:', round(f1, 2))


# label = dfOWA['truth'].values.astype(float)
# predictionOWA = dfOWA['OWA_value'].values.astype(float)
# metrics_calc(label, predictionOWA)