import sklearn.linear_model
import sklearn.ensemble
import matplotlib.pyplot as plt
from sklearn.metrics import *
from featuresVectorsAggregation import dfAggr
import numpy as np

label = dfAggr['truth'].values.astype(float)
prediction_means = dfAggr['mean'].values.astype(float)

#ROC CURVE
fpr, tpr, thresholds = roc_curve(label, prediction_means)
#print(thresholds)
#print(fpr, tpr)
roc_auc = auc(fpr, tpr)
#print(roc_auc)
plt.plot(fpr, tpr, lw=1, label='ROC (area = %0.2f)' % (roc_auc))


plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Luck')

#mean_auc = auc(fpr, tpr)
#plt.plot(fpr, tpr, 'k--',
# label='Mean ROC (AUC = %0.2f)' % mean_auc, lw=2)

plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.grid()
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")

plt.savefig("data/rocauc.pdf", format="pdf")
plt.show()

optimal_idx = np.argmax(tpr - fpr)
optimal_threshold = thresholds[optimal_idx]
print('Optimal threshold:', round( optimal_threshold, 4))
