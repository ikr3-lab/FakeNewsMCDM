import pandas as pd
import numpy as np
import math
import ast
import json
from choquet_integral_refactored import dfR_vTrain_training

inputFile = '3cred_event_TurkRatings.data'

# DataFrame creation with only 'topic_key' and 'Cred_Ratings' columns
dfRatings = pd.read_csv(inputFile, index_col='topic_key', sep='\t', usecols=['topic_key', 'Cred_Ratings'])
dfRatings['mean_ratings'] = ""
dfRatings['norm_mean'] = ""
#print(df)

for row in range(dfRatings.shape[0]):
    listRatings = dfRatings['Cred_Ratings'].values[row]
    listRatings = json.loads(listRatings)
    dfRatings['Cred_Ratings'].values[row] = listRatings
    dfRatings['mean_ratings'].values[row] = sum(listRatings)/len(listRatings)


dfRatings = dfRatings[(dfRatings['mean_ratings'] > 1.95) | (dfRatings['mean_ratings'] < 1.2)]
dfRatings = dfRatings.sort_index()

dfRatings = dfRatings.drop('ebola_free_sometimes-20141020_101221-20141020_111325')
dfRatings = dfRatings.drop('check_haha_#grammys-20150208_183650-20150208_194148')
dfRatings = dfRatings.drop('king_saudi_birthday-20150123_103938-20150123_114221')
dfRatings = dfRatings.drop('king_silver_saudi-20150123_160429-20150123_171441')
dfRatings = dfRatings.drop('left_fight_gordon-20141102_174738-20141102_184919')
dfRatings = dfRatings.drop('louis_ebola_nurse-20141024_170629-20141024_181626')
dfRatings = dfRatings.drop('october_ebola_house-20141015_230140-20141016_000502')
dfRatings = dfRatings.drop('ohio_state_alabama-20150101_211004-20150101_222556')
dfRatings = dfRatings.drop('ohio_state_game-20150101_233743-20150102_004727')
dfRatings = dfRatings.drop('rihanna_mom_grammys-20150208_183650-20150208_194148')
dfRatings = dfRatings.drop('raiders_obama_win-20141120_221830-20141120_232551')
dfRatings = dfRatings.drop('tonight_rivers_believe-20141023_225011-20141024_001313')

dfRatings = dfRatings.drop('ronaldo_ballon_cristiano-20150112_125026-20150112_134603-20150112_144438')
#print(dfRatings.index)


# Method to normalized the mean value with the statistic normalization formula
def normalize_mean(value, min, max):

    valNorm = (value - min) / (max - min)
    return valNorm

min_mean = min(dfRatings['mean_ratings'])
max_mean = max(dfRatings['mean_ratings'])
for row in range(dfRatings.shape[0]):
    dfRatings['norm_mean'].values[row] = normalize_mean(dfRatings['mean_ratings'].values[row],
                                                        min_mean, max_mean)

# Convert the features DataFrame to a dict to stored it neatly in a new json file
dictRatings = dfRatings.to_dict('index')
with open('data/mean_ratings.json', 'w') as file:
    json.dump(dictRatings, file, indent=4)

# Norm mean added as a new column of a new df from dfR_vTrain_training
dfR_vTrain_training_mean = dfR_vTrain_training
dfR_vTrain_training_mean['norm_mean_overall'] = ""
for rowTrain in range(dfR_vTrain_training_mean.shape[0]):
    for rowMean in range(dfRatings.shape[0]):
        if dfR_vTrain_training_mean.index[rowTrain] == dfRatings.index[rowMean]:
            dfR_vTrain_training_mean['norm_mean_overall'].values[rowTrain] = \
                dfRatings['norm_mean'].values[rowMean]

# Convert the features DataFrame to a dict to stored it neatly in a new json file for R
dictR_vTrain_training_mean = dfR_vTrain_training_mean.to_dict('index')
with open('data/dfR_vTrain_training_mean.json', 'w') as file:
    json.dump(dictR_vTrain_training_mean, file, indent=4)




