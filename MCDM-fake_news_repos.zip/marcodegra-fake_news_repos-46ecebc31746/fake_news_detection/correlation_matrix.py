import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from featuresNormalization import dfNorm
from golbeckTests import dfTrain

# Only TRUE events
dfTrainTrue = dfTrain[dfTrain.truth == 1]
x = dfTrainTrue[list(filter(lambda x: x != "truth", dfTrainTrue.columns))]
dfCorr = x.astype('float64').corr(method='pearson')
dfCorr = dfCorr.round(decimals=2)
#print(dfCorr)

# Heatmap
f, ax = plt.subplots(figsize=(20, 13))
sns.heatmap(dfCorr, mask=np.zeros_like(dfCorr, dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True),
            square=True, ax=ax, annot=True, linewidths=.5)
plt.savefig("data/corr_matrix_heatmap.pdf", format="pdf")
plt.savefig("data/corr_matrix_heatmap.png", format="png")
plt.show()

# # Scatter matrix
# pd.plotting.scatter_matrix(dfCorr, alpha = 0.3, figsize = (14,8), diagonal = 'kde');
# plt.savefig("data/corr_scatter_matrix.pdf", format="pdf")
# plt.show()
#
