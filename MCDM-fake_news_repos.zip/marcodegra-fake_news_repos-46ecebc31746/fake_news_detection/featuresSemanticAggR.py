from choquet_integral_refactored import dfR_vTrain_testing
from eventsRatings import dfR_vTrain_training_mean
import json
import numpy as np
from numpy import array

def more75(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i+1)/len(features_vector)
        if (f > 0 and f <= 0.75):
            q[i] = 0
        elif (f > 0.75 and f <= 1):
            q[i] = (f-0.75)/(1-0.75)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i-1]
    weights = weights.tolist()

    value = 0
    for i in range(len(features_vector)):
        value += features_vector[i] * weights[i]

    return value

# Training
dfR4cat_train = dfR_vTrain_training_mean
dfR4cat_train['structural'] = ''
dfR4cat_train['user'] = ''
dfR4cat_train['content'] = ''
dfR4cat_train['temporal'] = ''

for row in range(dfR4cat_train.shape[0]):
    structurals = []
    structurals.extend([dfR4cat_train['mediaCount'].values[row],
                         dfR4cat_train['hashtagCount'].values[row],
                         dfR4cat_train['mentionCount'].values[row],
                         dfR4cat_train['status_count'].values[row],
                         dfR4cat_train['urlCount'].values[row],
                         dfR4cat_train['tweetCount'].values[row],
                         dfR4cat_train['retweetCount'].values[row]])
    features_vector = array(structurals)
    dfR4cat_train['structural'].values[row] = more75(features_vector)

    users = []
    users.extend([dfR4cat_train['verified'].values[row],
                        dfR4cat_train['density'].values[row],
                        dfR4cat_train['followers'].values[row],
                        dfR4cat_train['friends'].values[row]])
    features_vector = array(users)
    dfR4cat_train['user'].values[row] = more75(features_vector)

    contents = []
    contents.extend([dfR4cat_train['polarity'].values[row],
                  dfR4cat_train['objectivity'].values[row]])
    features_vector = array(contents)
    dfR4cat_train['content'].values[row] = more75(features_vector)

    temporals = []
    temporals.extend([dfR4cat_train['lifespan'].values[row],
                    dfR4cat_train['ages'].values[row]])
    features_vector = array(temporals)
    dfR4cat_train['temporal'].values[row] = more75(features_vector)

dfR4cat_train = dfR4cat_train.drop(["ages", "friends", "mediaCount", "density", "lifespan", "tweetCount",
                         "objectivity", "polarity", "retweetCount", "mentionCount", "verified", "hashtagCount", "followers",
                         "status_count", "urlCount",], axis=1)
dfR4cat_train = dfR4cat_train[['structural', 'user', 'content', 'temporal', 'norm_mean_overall', 'truth']]

# Testing
dfR4cat_test = dfR_vTrain_testing
dfR4cat_test['structural'] = ''
dfR4cat_test['user'] = ''
dfR4cat_test['content'] = ''
dfR4cat_test['temporal'] = ''

for row in range(dfR4cat_test.shape[0]):
    structurals = []
    structurals.extend([dfR4cat_test['mediaCount'].values[row],
                        dfR4cat_test['hashtagCount'].values[row],
                        dfR4cat_test['mentionCount'].values[row],
                        dfR4cat_test['status_count'].values[row],
                        dfR4cat_test['urlCount'].values[row],
                        dfR4cat_test['tweetCount'].values[row],
                        dfR4cat_test['retweetCount'].values[row]])
    features_vector = array(structurals)
    dfR4cat_test['structural'].values[row] = more75(features_vector)

    users = []
    users.extend([dfR4cat_test['verified'].values[row],
                  dfR4cat_test['density'].values[row],
                  dfR4cat_test['followers'].values[row],
                  dfR4cat_test['friends'].values[row]])
    features_vector = array(users)
    dfR4cat_test['user'].values[row] = more75(features_vector)

    contents = []
    contents.extend([dfR4cat_test['polarity'].values[row],
                     dfR4cat_test['objectivity'].values[row]])
    features_vector = array(contents)
    dfR4cat_test['content'].values[row] = more75(features_vector)

    temporals = []
    temporals.extend([dfR4cat_test['lifespan'].values[row],
                      dfR4cat_test['ages'].values[row]])
    features_vector = array(temporals)
    dfR4cat_test['temporal'].values[row] = more75(features_vector)

dfR4cat_test = dfR4cat_test.drop(["ages", "friends", "mediaCount", "density", "lifespan", "tweetCount",
                         "objectivity", "polarity", "retweetCount", "mentionCount", "verified", "hashtagCount", "followers",
                         "status_count", "urlCount",], axis=1)
dfR4cat_test = dfR4cat_test[['structural', 'user', 'content', 'temporal', 'truth']]


# Convert the 4cat DFs to a dict to stored it neatly in a new json file for R
dictDfR4cat_train = dfR4cat_train.to_dict('index')
with open('data/dfR4cat_train.json', 'w') as file:
    json.dump(dictDfR4cat_train, file, indent=4)

dictDfR4cat_test = dfR4cat_test.to_dict('index')
with open('data/dfR4cat_test.json', 'w') as file:
    json.dump(dictDfR4cat_test, file, indent=4)