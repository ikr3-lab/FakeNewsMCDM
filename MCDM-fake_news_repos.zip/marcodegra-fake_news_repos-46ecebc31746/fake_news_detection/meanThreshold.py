import sklearn.linear_model
import sklearn.ensemble
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import *
from featuresVectorsAggregation import dfAggr


def mean_split(threshold_par):
    true_count=false_count = 0
    tp=tn=fp=fn = 0
    prediction = []
    # For each event
    for row in range(dfAggr.shape[0]):
        #print('\n\nmean', dfAggr['mean'].values[row])
        #print('truth', dfAggr['truth'].values[row])
        if dfAggr['mean'].values[row] >= threshold_par:
            prediction.append(1)
            # true_count += 1
            # if dfAggr['truth'].values[row] == 1:
            #     tp += 1
            #     #print(1, 'tp')
            # else:
            #     fp += 1
            #     #print(1, 'fp')
        else:
            prediction.append(0)
            # false_count += 1
            # if dfAggr['truth'].values[row] == 1:
            #     fn += 1
            #     #print(0, 'fn')
            # else:
            #     tn += 1
            #     #print(0, 'tn')

    #return (prediction, true_count, false_count, tp, tn, fp, fn)
    return (prediction)


def metrics_results(threshold, label, prediction, confusion_matrix):

    #prediction = dfAggr['mean'].values
    #ValueError: Classification metrics can't handle a mix of binary and continuous targets
    #print(prediction)


    #Metrics

    # Proportion of true results (both true positives and true negatives)
    # among the total number of cases examined
    accuracy = accuracy_score(label, prediction)

    #
    precision = precision_score(label, prediction)

    # TPR/Recall/Sensitivity
    recall = recall_score(label, prediction)

    # A measure that combines precision and recall is
    # the harmonic mean of precision and recall
    f1 = f1_score(label, prediction)

    print('Threshold:', threshold)
    print('True (>', threshold, '):', prediction.count(1))
    print('False (<', threshold, '):', prediction.count(0))
    print('True Positive:', confusion_matrix[1][1], 'True Negative:', confusion_matrix[0][0],
           '\nFalse Positive:', confusion_matrix[0][1], 'False Negative:', confusion_matrix[1][0])
    print('Accuracy:', round(accuracy, 2))
    print('Precision:', round(precision, 2))
    print('Recall:', round(recall, 2))
    print('F1-score:', round(f1, 2))

    # print('Threshold:', threshold,
    #        file=open("data/mean_threshold.txt", "a"))
    # print('True (>', threshold, '):', prediction.count(1),
    #        file=open("data/mean_threshold.txt", "a"))
    # print('False (<', threshold, '):', prediction.count(0),
    #        file=open("data/mean_threshold.txt", "a"))
    # print('True Positive:', confusion_matrix[1][1], 'True Negative:', confusion_matrix[0][0],
    #        '\nFalse Positive:', confusion_matrix[0][1], 'False Negative:', confusion_matrix[1][0], '\n\n',
    #        file=open("data/mean_threshold.txt", "a"))

    ######################################################################
    # The optimal cut off would be where tpr is high and fpr is low      #
    # tpr - (1-fpr) is zero or near to zero is the optimal cut off point #
    ######################################################################

    #ROC CURVE
    fpr, tpr, thresholds = roc_curve(label, prediction)
    #print(thresholds)
    #print(fpr, tpr)
    roc_auc = auc(fpr, tpr)
    #print(roc_auc)
    plt.plot(fpr, tpr, lw=1, label='ROC (area = %0.2f)' % (roc_auc))


    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Luck')

    #mean_auc = auc(fpr, tpr)
    #plt.plot(fpr, tpr, 'k--',
    # label='Mean ROC (AUC = %0.2f)' % mean_auc, lw=2)

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.grid()
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")

    plt.savefig("data/rocauc.pdf", format="pdf")
    plt.show()


def main(threshold):
    prediction = mean_split(threshold)

    # Build the confusion matrix
    label = dfAggr['truth'].values.astype(int)
    confusion_matrix = sklearn.metrics.confusion_matrix(label, prediction)
    #print(confusion_matrix)

    metrics_results(threshold, label, prediction, confusion_matrix)


main(0.088)
