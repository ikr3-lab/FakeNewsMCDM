from featuresNormalization import dfNorm

import json
import pandas as pd

x = dfNorm[list(filter(lambda x: x != "truth", dfNorm.columns))]
y = dfNorm["truth"]

xData = x.as_matrix()
yData = y.as_matrix()

# Create a dict of events as arrays of their features, order by an aggregator operator, and their truth label
eventsOrdered = {}
for eventIndex in range(xData.shape[0]):
    eventsOrdered[dfNorm.index[eventIndex]] = {'features': xData[eventIndex].tolist(),
                                               'mean': xData[eventIndex].mean(),
                                               'truth': yData[eventIndex]}

# New pandas DataFrame from the eventsOrdered to sort it by mean in descending order
dfAggr = pd.DataFrame(eventsOrdered)
# Fix the orientation
dfAggr = dfAggr.transpose()
# Sorting by mean in descending order
dfAggr = dfAggr.sort_values('mean', ascending=False)
# Convert the dfAggr to a dict to store it neatly in a json file
dfAggrDict = dfAggr.to_dict(orient='index')
with open('data/eventsOrderedByMean.json', 'w') as file:
     json.dump(dfAggrDict, file, indent=4)

