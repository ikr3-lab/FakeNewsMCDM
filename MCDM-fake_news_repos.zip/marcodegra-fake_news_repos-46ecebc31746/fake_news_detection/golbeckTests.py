import sklearn.linear_model
import sklearn.ensemble
import pandas as pd
from sklearn import svm
from scipy import interp
from sklearn.metrics import *
from sklearn.tree import DecisionTreeClassifier
from sklearn.cross_validation import StratifiedKFold
import json
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.svm import SVR

from sklearn.model_selection import train_test_split


def splitSet(file):
    df = pd.read_json(file, orient='index')

    # y contains all the truth values (0 or 1)
    y = df["truth"]

    dfTrain, dfTest = train_test_split \
        (df, test_size=0.66, stratify=y, random_state=1)
    #print(trainDf.shape)
    #print(trainDf["truth"])

    # Convert the training DataFrame to a dict
    # to correctly stored it in a json file
    dfTrainDict = dfTrain.to_dict('index')
    with open('data/train.json', 'w') as file:
        json.dump(dfTrainDict, file, indent=4)
    # Convert the testing DataFrame to a dict
    # to correctly stored it in a json file
    dfTestDict = dfTest.to_dict('index')
    with open('data/test.json', 'w') as file:
        json.dump(dfTestDict, file, indent=4)

    return (dfTrain, dfTest)


def loadFeatures(file, features_out):

    df = pd.read_json(file, orient='index')
    #print(df["status_count"].mean())

    # y contains all the truth values (0 or 1)
    y = df["truth"]
    # x contains all features except the 'truth'
    x = df[list(filter(lambda x: x not in features_out, df.columns))]
    #print(x)

    print('Training data shape (rows, cols):', x.shape)
    print('Features OUT:', features_out)

    return (x.as_matrix(), y.as_matrix())


def metrics_calc(cls, xData, yData):

    #print('Classifier:', cls.)
    plt.figure(figsize=(8, 6))

    # WHY ON yData AND NOT xData?
    cv = StratifiedKFold(yData, n_folds=5)

    # tpr: True Positive rate
    # fpr: False Positive rate
    mean_tpr = 0.0
    mean_fpr = np.linspace(0, 1, 100)
    all_tpr = []

    mean_accuracy = 0.0
    mean_precision = 0.0
    mean_recall = 0.0
    mean_f1 = 0.0

    mean_optimal_threshold = 0.0

    for i, (train, test) in enumerate(cv):
        #print('Fold', i)
        probas_ = cls.fit(xData[train], yData[train]).predict_proba(xData[test])
        #print(probas_[i])

        # Truth values prediction for metrics calculation
        prediction = cls.fit(xData[train], yData[train]).predict(xData[test])
        #print(prediction[i])

        label = yData[test].astype(float)

        accuracy = accuracy_score(label, prediction)
        precision = precision_score(label, prediction)
        recall = recall_score(label, prediction)
        f1 = f1_score(label, prediction)

        # Compute ROC curve and area the curve
        fpr, tpr, thresholds = roc_curve(yData[test], probas_[:, 1])
        #print(roc_curve(yData[test], probas_[:, 1]))
        roc_auc = auc(fpr, tpr)
        #print(roc_auc)
        plt.plot(fpr, tpr, lw=1, label='ROC fold %d (area = %0.2f)' % (i, roc_auc))

        optimal_idx = np.argmax(tpr - fpr)
        optimal_threshold = thresholds[optimal_idx]

        # Update means
        mean_tpr += interp(mean_fpr, fpr, tpr)
        mean_tpr[0] = 0.0

        mean_accuracy += accuracy
        mean_precision += precision
        mean_recall += recall
        mean_f1 += f1

        mean_optimal_threshold += optimal_threshold

        optimal_idx = np.argmax(tpr - fpr)
        optimal_threshold = thresholds[optimal_idx]

    #print(probas_)
    #print(prediction)

    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Luck')

    mean_tpr /= len(cv)
    mean_tpr[-1] = 1.0
    mean_auc = auc(mean_fpr, mean_tpr)
    plt.plot(mean_fpr, mean_tpr, 'k--',
             label='Mean ROC (AUC = %0.2f)' % mean_auc, lw=2)

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.grid()
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")

    plt.savefig("data/rocauc.pdf", format="pdf")
    plt.show()


    mean_accuracy /= len(cv)
    print('\nMean ACCURACY:', round(mean_accuracy, 2))
    mean_precision /= len(cv)
    print('Mean PRECISION:', round(mean_precision, 2))
    mean_recall /= len(cv)
    print('Mean RECALL:', round(mean_recall, 2))
    mean_f1 /= len(cv)
    print('Mean F1-SCORE:', round(mean_f1, 2))

    mean_optimal_threshold /= len(cv)
    print('\nMean optimal ROC-AUC threshold:', round(mean_optimal_threshold, 4))


# RUN
file = 'data/normalized_ordered_features.json'
(dfTrain, dfTest) = splitSet(file)

jsonFile = 'data/normalized_ordered_features.json'
features_out = ["truth"]
# CATEGORY features
features_out.extend([])
(xData, yData) = loadFeatures(jsonFile, features_out)

# Random Forest
#cls = sklearn.ensemble.RandomForestClassifier(n_estimators=100)

# Logistic Regression
#cls = sklearn.linear_model.LogisticRegression()

# SVM
#cls = SVR(cache_size=7000)
cls = svm.SVC(kernel='linear')

#Decision Tree
#cls = DecisionTreeClassifier()

#kNN
#cls = sklearn.neighbors.KNeighborsClassifier(n_neighbors=5, weights='uniform', algorithm='auto', leaf_size=30, p=2, metric='minkowski', metric_params=None)

# Gaussian Naive Bayes
#cls = GaussianNB()

# Bernoulli Naive Bayes
#cls = BernoulliNB()

metrics_calc(cls, xData, yData)
