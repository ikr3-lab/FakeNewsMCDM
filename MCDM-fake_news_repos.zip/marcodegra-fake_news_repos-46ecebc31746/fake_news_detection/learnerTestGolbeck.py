import sklearn.linear_model
import sklearn.ensemble
import pandas as pd
from sklearn import svm
from sklearn.metrics import roc_curve, auc
from scipy import interp
from sklearn.cross_validation import StratifiedKFold
import json
import matplotlib.pyplot as plt
import numpy as np

def loadFeatures(file):

    df = pd.read_json(file, orient='index')
    # y contains all the truth values (0 or 1)
    y = df["truth"]
    # x contains all features except the 'truth'
    x = df[list(filter(lambda x: x != "truth", df.columns))]

    return (x.as_matrix(), y.as_matrix())

jsonFile = 'data/credbank_features.json'
(xData, yData) = loadFeatures(jsonFile)
#print(xData)

#======================================================================

plt.figure(figsize=(8, 6))

#WHY ON yData AND NOT xData?
cv = StratifiedKFold(yData, n_folds=5)

#cls = sklearn.linear_model.LogisticRegression()
#cls = svm.SVC(kernel='linear', probability=True)
cls = sklearn.ensemble.RandomForestClassifier(n_estimators=100)

# tpr: True Positive rate
# fpr: False Positive rate
mean_tpr = 0.0
mean_fpr = np.linspace(0, 1, 100)
all_tpr = []

for i, (train, test) in enumerate(cv):
    print(i)
    probas_ = cls.fit(xData[train], yData[train]).predict_proba(xData[test])

    # Compute ROC curve and area the curve
    fpr, tpr, thresholds = roc_curve(yData[test], probas_[:, 1])
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, lw=1, label='ROC fold %d (area = %0.2f)' % (i, roc_auc))

    # Update means
    mean_tpr += interp(mean_fpr, fpr, tpr)
    mean_tpr[0] = 0.0


plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Luck')

mean_tpr /= len(cv)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
plt.plot(mean_fpr, mean_tpr, 'k--',
         label='Mean ROC (AUC = %0.2f)' % mean_auc, lw=2)


plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.grid()
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")

plt.savefig("data/rocauc.pdf", format="pdf")
plt.show()

optimal_idx = np.argmax(tpr - fpr)
optimal_threshold = thresholds[optimal_idx]
print('\nOptimal ROC-AUC threshold:', round( optimal_threshold, 4))