import numpy as np

V = np.empty([1, 4])
V = V.flatten()
V[0] = 1; V[1] = 0.6; V[2] = 0.5; V[3] = 0.9

def weightsOWA_f2I(features_vector):

    ########################################################
    a = features_vector
    print('A:', a)
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))
    print('b:', b)

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, 4])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = V[i]
    print('u:', u)

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    print('T:', t)
    summation = np.empty([1, 4])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
            q[k] = summation[k]**2


    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]
    print('w:', weights)


    return weights.tolist()


# Computation of the aggregation value
def calc_aggr_value(features_vector, weight_vector):
    value = 0
    for i in range(len(features_vector)):
        print(features_vector[i], '*', weight_vector[i])
        value += features_vector[i] * weight_vector[i]

    return round(value, 3)


x = np.empty([1, 4])
x = V.flatten()
x[0] = 0.7; x[1] = 1; x[2] = 0.5; x[3] = 0.6
print('D:', calc_aggr_value((-np.sort(-x)), weightsOWA_f2I(x)))


y = np.empty([1, 4])
y = V.flatten()
y[0] = 0.6; y[1] = 0.3; y[2] = 0.9; y[3] = 1
print()
print('D:', calc_aggr_value((-np.sort(-y)), weightsOWA_f2I(y)))
