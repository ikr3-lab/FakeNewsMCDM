import numpy as np
import pandas as pd
# Importing of DataFrame with the 15 features (all except of 'truth')
from correlation_matrix import x as dfNorm15, dfCorr
from newOWA_aggregation import v

# Defining of all singleton importance values I_i

# I_i length = dfNorm15.shape[1]+1 = 15 + 1 = number of features + I_i(0)=0
I_i = np.empty([1, dfNorm15.shape[1]])
I_i = I_i.flatten()
for i in range(dfNorm15.shape[1]):
    # if i == 0:
    #     I_i[i] = 0
    # else:
    I_i[i] = round(v[i]/sum(v), 3)

#print(I_i)


# Matrix of I_ij[i,j]

# I_ij shape = dfNorm15.shape[1] rows and dfNorm15.shape[1] cols = 15x15 = (0,14)x(0,14)
I_ij = np.zeros([dfNorm15.shape[1], dfNorm15.shape[1]])
I_ij = np.zeros([dfNorm15.shape[1], dfNorm15.shape[1]])

# Calculation of I_ij[i,j] values
const_plus = 0
const_minus = 0
const = 1

for i in range(dfNorm15.shape[1]):
    for j in range(dfNorm15.shape[1]):
        if i != j:
            # i/j + 1 only for adjusting indexes
            if (dfCorr.iloc[i,j] > 0):
                # corr POS: dfCorr[i,j] + constant
                #I_ij[i,j] = dfCorr.iloc[i,j] + const_plus
                #I_ij[i, j] = dfCorr.iloc[i, j]/const
                I_ij[i,j] = (dfCorr.iloc[i,j] * I_i[i])/15
            elif (dfCorr.iloc[i,j] < 0):
                # corr NEG: dfCorr[i,j] - constant
                #I_ij[i,j] = dfCorr.iloc[i,j] - const_minus
                #I_ij[i, j] = dfCorr.iloc[i, j]/const
                I_ij[i,j] = (dfCorr.iloc[i,j] * I_i[i])/15
        else:
            I_ij[i,j] = None

# Assign the same value to the simmetric half of I[i,j]
for i in range(I_ij.shape[0]):
    for j in range(I_ij.shape[1]):
        if j<i:
            I_ij[i, j] = I_ij[j, i]

cols = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
df_I_ij = pd.DataFrame(I_ij, columns=cols, index=cols)

#################################################################################

# Importance/Shapley and Interaction indexes constraints satisfaction

# SUM(i=1 to n) I[i] = 1
def sumI_i(impor_i):
    summation = 0
    for i in range(impor_i.shape[0]):
        summation += impor_i[i]

    return summation

print('Summation of all Importance values =', sumI_i(I_i))


# -1 <= I[i,j] <= 1
def rangeI_ij(inter_ij):
    count_no = 0
    for i in range(inter_ij.shape[0]):
        for j in range(inter_ij.shape[1]):
            if i != j:
                if inter_ij[i,j] >= -1 and inter_ij[i,j] <= 1:
                    pass
                else:
                    count_no += 1
                    print(inter_ij[i,j])

    if count_no == 0:
        out = 'OK! All I[i,j] in range [-1,1]'
    else:
        out = 'NOT all I[i,j] in range [-1,1]!!!'

    return out

print(rangeI_ij(I_ij))


def choquet_property(impor_i, inter_ij):
    # Replace NaN (except i = j) with simmetric value
    # to obtain a complete row for the computation
    # for i in range(inter_ij.shape[0]):
    #     for j in range(inter_ij.shape[1]):
    #         if i != j:
    #             # i/j + 1 only for adjusting indexes
    #             if (dfCorr.iloc[i,j] > 0):
    #                 # corr POS: dfCorr[i,j] + constant
    #                 #inter_ij[i,j] = dfCorr.iloc[i,j] + const_plus
    #                 #inter_ij[i, j] = dfCorr.iloc[i, j]/const
    #                 inter_ij[i,j] = (dfCorr.iloc[i,j] * I_i[i + 1])/15
    #             elif (dfCorr.iloc[i,j] < 0):
    #                 # corr NEG: dfCorr[i,j] - constant
    #                 #inter_ij[i,j] = dfCorr.iloc[i,j] - const_minus
    #                 #inter_ij[i, j] = dfCorr.iloc[i, j]/const
    #                 inter_ij[i,j] = (dfCorr.iloc[i,j] * I_i[i + 1])/15


    count_no = 0
    for i in range(inter_ij.shape[0]):
        summ = 0
        for j in range(inter_ij.shape[1]):
            if i != j:
                summ += abs(inter_ij[i,j])
                #print('\n',abs(inter_ij[i,j]), '+')
        #print(i+1, summ)

        formula = (impor_i[i] - (0.5 * summ))
        #print(impor_i[i+1], '-0.5*', summ)
        #print(i, 'property', formula)
        if formula >= 0:
            pass
        else:
            count_no += 1

    # Restore the half NaN values
    # for i in range(inter_ij.shape[0]):
    #     for j in range(inter_ij.shape[1]):
    #         if j < i:
    #             inter_ij[i, j] = None


    if count_no == 0:
        out = "OK! Property satisfied"
    else:
        out = "Property NOT satisfied!!!"

    return out

print(choquet_property(I_i, I_ij))

#################################################################################

# 2-additive Choquet Integral computation
from newOWA_aggregation import xData, yData
from featuresNormalization import dfNorm
import json

def calc_choquet(f_val, impor_i, inter_ij):
    sum_interPos = 0
    sum_interNeg = 0
    for i in range(inter_ij.shape[0]):
        for j in range(inter_ij.shape[1]):
            if i != j:
                if inter_ij[i,j] > 0:
                    sum_interPos += min(f_val[i], f_val[j]) * (inter_ij[i,j])
                    #print('I[', i+1, ',', j+1, ']', inter_ij[i,j], 'fval', i+1, f_val[i], 'fval', j+1, f_val[j])
                elif inter_ij[i,j] < 0:
                    sum_interNeg += max(f_val[i], f_val[j]) * abs(inter_ij[i, j])
                    #print('I[', i + 1, ',', j + 1, ']', inter_ij[i, j], 'fval', i + 1, f_val[i], 'fval', j + 1, f_val[j])
        #print('SUM', sum_interPos)
        #print('SUM', sum_interNeg)

    last_part = 0
    for i in range(inter_ij.shape[0]):
        summ = 0
        for j in range(inter_ij.shape[1]):
            if i != j:
                summ += abs(inter_ij[i,j])
                #print('\n',abs(inter_ij[i,j]), '+')
        #print('\n', i+1, summ)

        formula = (impor_i[i] - (0.5 * summ))
        #print('vi', i+1, impor_i[i+1])
        #print('formula choq int', i, formula)
        last_part += f_val[i] * formula
        #print('last part', last_part)


    result = sum_interPos + sum_interNeg + last_part
    print(result)
    return result


valori = np.empty([1, 4])
valori = valori.flatten()
#7 17 14
valori[0]=1; valori[1]=1; valori[2]=0.75; valori[3]=0.25
impo = np.empty([1, 4])
impo = impo.flatten()
#0.25 0.5 0.25
impo[0]= 0.8; impo[1]= 0.72; impo[2]= 0.88; impo[3]= 1.6
inte = np.zeros([4, 4])
#I12 0.5 I13 0 I23 -0.5
inte[0,1]= -0.04; inte[0,2]= 0.23; inte[0,3]= 0.13; inte[1,2] = 0; inte[1,3]= 0.31; inte[2,3]= 0.21
#print(inte)
calc_choquet(valori, impo, inte)
quit()

#JSON file creation with: features values, weights, OWA value, truth label
eventsChoquet = {}
for eventIndex in range(xData.shape[0]):
    eventsChoquet[dfNorm.index[eventIndex]] = {'features': xData[eventIndex].tolist(),
                                               'Choquet-Integral value': calc_choquet(xData[eventIndex],
                                                                                        I_i, I_ij),
                                               'truth': yData[eventIndex]}

# New pandas DataFrame from the eventsOrdered to sort it by mean in descending order
dfChoquet = pd.DataFrame(eventsChoquet)
# Fix the orientation
dfChoquet = dfChoquet.transpose()
# Sorting by Choquet value in descending order
#dfChoquet = dfChoquet.sort_values('Choquet-Integral value', ascending=False)
# Convert the dfOWA to a dict to store it neatly in a json file
dict_dfChoquet = dfChoquet.to_dict(orient='index')
#print(dict_dfChoquet)
filename = 'data/eventsChoquetIntegral.json'
with open(filename, 'w') as file:
    output = json.dump(dict_dfChoquet, file, indent = 4)

label = dfChoquet['truth'].values.astype(float)
predictionChoquet = dfChoquet['Choquet-Integral value'].values.astype(float)
from rocOWA import metrics_calc
metrics_calc(label, predictionChoquet)