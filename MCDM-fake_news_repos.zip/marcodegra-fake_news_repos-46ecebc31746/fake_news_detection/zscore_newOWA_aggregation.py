import json
import pandas as pd
import numpy as np
import math
from featuresNormalization import dfZscore
from rocOWA import metrics_calc

# 'am' stands for Arithmetic Mean
def weightsOWA_am(features_vector):

    features_vector = (-np.sort(-features_vector))

    weights = np.empty([1, len(features_vector)])
    weights.fill(1/len(features_vector))
    weights = weights.flatten()

    return weights.tolist()

# 'wm' stands for Weighted Mean
# def weightsOWA_wm(features_vector):
#     weights = np.empty([1, len(features_vector)])
#     weights.fill(0.5/len(features_vector))
#     weights = weights.flatten()
#
#     weights[verified_col] = 1/len(features_vector)
#
#     return weights.tolist()

def weightsOWA_max(features_vector):

    features_vector = (-np.sort(-features_vector))

    weights = []
    for i in range(len(features_vector)):
        if i == 0:
            weights.append(1)
        else:
            weights.append(0)

    return weights


def weightsOWA_min0(features_vector):

    features_vector = (-np.sort(-features_vector))

    weights = []
    for i in range(len(features_vector)):
        if i != (len(features_vector) - 1) :
            weights.append(0)
        else:
            weights.append(1)

    return weights


def weightsOWA_min(features_vector):
    features_vector = (-np.sort(-features_vector))

    # Initialize an empty numpy array
    weights = np.zeros([1, len(features_vector)])
    minIndex = np.min(features_vector[np.nonzero(features_vector)])
    for i in range(len(features_vector)):
        if features_vector[i] == minIndex:
            weights[0, i] = 1

    weights = weights.flatten()

    return weights.tolist()


def weightsOWA_decr(features_vector):

    features_vector = (-np.sort(-features_vector))

    weights = []
    # Give a via via a minor weights from 1 to 0
    for i in range(len(features_vector)):
        weights.append((1 - (0.06 * i)) / len(features_vector))

    return weights

def weightsOWA_al50(features_vector):

    features_vector = (-np.sort(-features_vector))

    weights = []
    for i in range(len(features_vector)):
        # vector_len=15, i < 7
        if i < (((len(features_vector) + 1)/2)-1):
            weights.append(1 / 15)
        # vector_len=15, i > 7
        elif i > (((len(features_vector) + 1)/2)-1):
            weights.append(0 / 15)
        # vector_len=15, i = 7
        else:
            weights.append(0.5 / 15)

    return weights

# Linguistic Quantifiers
def weightsOWA_more25(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i+1)/len(features_vector)
        if (f > 0 and f <= 0.25):
            q[i] = 0
        elif (f > 0.25 and f <= 1):
            q[i] = (f-0.25)/(1-0.25)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more50(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i+1)/len(features_vector)
        if (f > 0 and f <= 0.5):
            q[i] = 0
        elif (f > 0.5 and f <= 1):
            q[i] = (f-0.5)/(1-0.5)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more75(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i+1)/len(features_vector)
        if (f > 0 and f <= 0.75):
            q[i] = 0
        elif (f > 0.75 and f <= 1):
            q[i] = (f-0.75)/(1-0.75)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_most(features_vector):

    features_vector = (-np.sort(-features_vector))

    most_lower = 0.3
    most_upper = 0.8

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i + 1) / len(features_vector)
        if (f > 0 and f <= most_lower):
            q[i] = 0
        elif (f > most_lower and f < most_upper):
            q[i] = (f - most_lower) / (most_upper - most_lower)
        elif (f >= most_upper):
            q[i] = 1

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

def weightsOWA_log_10(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i + 1) / len(features_vector)
        q[i] = math.log(f, 10) + 1

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

def weightsOWA_1ef(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i + 1) / len(features_vector)
        q[i] = 1-math.exp(-f)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

def weightsOWA_f2(features_vector):

    features_vector = (-np.sort(-features_vector))

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for i in range(len(features_vector)):
        f = (i + 1) / len(features_vector)
        q[i] = f**2

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

#Linguistic Quantifiers with IMPORTANCE

# Definition of Importance values v[i]
# v1 = v[0]!!!

v = np.empty([1, dfZscore.shape[1]-1])
v = v.flatten()
v[0] = 0.33; v[1] = 0.12; v[2] = 0.41; v[3] = 0.84; v[4] = 0.43; v[5] = 0.39; v[6] = 0.10
v[7] = 0.35; v[8] = 0.67; v[9] = 0.51; v[10] = 0.49; v[11] = 0.5; v[12] = 0.47; v[13] = 0.56; v[14] = 0.9

vTrain = np.empty([1, dfZscore.shape[1]-1])
vTrain = vTrain.flatten()
vTrain[0] = 0.9; vTrain[1] = 0.612; vTrain[2] = 0.3; vTrain[3] = 0.836; vTrain[4] = 0.356; vTrain[5] = 0.564; vTrain[6] = 0.724
vTrain[7] = 0.396; vTrain[8] = 0.55; vTrain[9] = 0.54; vTrain[10] = 0.532; vTrain[11] = 0.196; vTrain[12] = 0.554; vTrain[13] = 0.11; vTrain[14] = 0.364



vScale = np.empty([1, dfZscore.shape[1]-1])
vScale = vScale.flatten()
vScale[0] = 2; vScale[1] = 1; vScale[2] = 2; vScale[3] = 4; vScale[4] = 2; vScale[5] = 2; vScale[6] = 1
vScale[7] = 2; vScale[8] = 3; vScale[9] = 3; vScale[10] = 2; vScale[11] = 3; vScale[12] = 2; vScale[13] = 3; vScale[14] = 4

#v[0] = 0.014; v[1] = 0.001; v[2] = 0.014; v[3] = 0.014; v[4] = 0.25; v[5] = 0.014; v[6] = 0.001
#v[7] = 0.014; v[8] = 0.1; v[9] = 0.1; v[10] = 0.014; v[11] = 0.1; v[12] = 0.014; v[13] = 0.1; v[14] = 0.25

# OWA + I (v)
def weightsOWA_mostI(features_vector):

    features_vector = (-np.sort(-features_vector))
    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = v[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    most_lower = 0.5
    most_upper = 0.6

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= most_lower):
            q[k] = 0
        elif (summation[k] > most_lower and summation[k] < most_upper):
            q[k] = (summation[k] - most_lower) / (most_upper - most_lower)
        elif (summation[k] >= most_upper):
            q[k] = 1

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

def weightsOWA_more75I(features_vector):

    #features_vector = (-np.sort(-features_vector))
    #print(features_vector)
    ########################################################
    #print(features_vector)
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))
    #print('b', b)

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(features_vector)):
            #print('i', i, 'a[i]', a[i], 'j', j, 'b[j]', b[j], 'v[i]', v[i], 'u[j]', round(u[j],2))
            if a[i] == b[j]:
                u[j] = v[i]
    #print('v', v)
    #print('u', u)

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################
    #print('sum', summation)

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.75):
            q[k] = 0
        elif (summation[k] > 0.75 and summation[k] <= 1):
            q[k] = (summation[k] - 0.75) / (1 - 0.75)

    #print('q', round(q[14], 2), round(q[13],2))

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]

    # print('w', round(q[i], 2),'-', round(q[i-1],2))
    #print('w', weights, '\n')


    return weights.tolist()

def weightsOWA_most_more75_I(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = v[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################
    #print(summation)

    most_lower = 0.5
    most_upper = 0.6

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if summation[k] < 0.5:
            # Most QL
            if (summation[k] > 0 and summation[k] <= most_lower):
                q[k] = 0
            elif (summation[k] > most_lower and summation[k] < most_upper):
                q[k] = (summation[k] - most_lower) / (most_upper - most_lower)
            elif (summation[k] >= most_upper):
                q[k] = 1
        else:
            # More75 QL
            if (summation[k] > 0 and summation[k] <= 0.75):
                q[k] = 0
            elif (summation[k] > 0.75 and summation[k] <= 1):
                q[k] = (summation[k] - 0.75) / (1 - 0.75)


    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more25I(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = v[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.25):
            q[k] = 0
        elif (summation[k] > 0.25 and summation[k] <= 1):
            q[k] = (summation[k] - 0.25) / (1 - 0.25)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more50I(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = v[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.5):
            q[k] = 0
        elif (summation[k] > 0.5 and summation[k] <= 1):
            q[k] = (summation[k] - 0.5) / (1 - 0.5)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_f2I(features_vector):

    features_vector = (-np.sort(-features_vector))

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = v[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
            q[k] = summation[k]**2


    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

# OWA + I (Shapley)
#def weightsOWA_more75I_shapley(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = v[i]/sum(v)
    #print(u)

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.75):
            q[k] = 0
        elif (summation[k] > 0.75 and summation[k] <= 1):
            q[k] = (summation[k] - 0.75) / (1 - 0.75)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

# OWA + I (vScale)
def weightsOWA_mostI_vScale(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vScale[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    most_lower = 0.5
    most_upper = 0.6

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= most_lower):
            q[k] = 0
        elif (summation[k] > most_lower and summation[k] < most_upper):
            q[k] = (summation[k] - most_lower) / (most_upper - most_lower)
        elif (summation[k] >= most_upper):
            q[k] = 1

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        else:
            weights[i] = q[i] - q[i - 1]


    return weights.tolist()

def weightsOWA_more75I_vScale(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vScale[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.75):
            q[k] = 0
        elif (summation[k] > 0.75 and summation[k] <= 1):
            q[k] = (summation[k] - 0.75) / (1 - 0.75)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_most_more75_I_vScale(features_vector):


    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vScale[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    most_lower = 0.5
    most_upper = 0.6

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if summation[k] < 0.5:
            # Most QL
            if (summation[k] > 0 and summation[k] <= most_lower):
                q[k] = 0
            elif (summation[k] > most_lower and summation[k] < most_upper):
                q[k] = (summation[k] - most_lower) / (most_upper - most_lower)
            elif (summation[k] >= most_upper):
                q[k] = 1
        else:
            # More75 QL
            if (summation[k] > 0 and summation[k] <= 0.75):
                q[k] = 0
            elif (summation[k] > 0.75 and summation[k] <= 1):
                q[k] = (summation[k] - 0.75) / (1 - 0.75)


    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more50I_vScale(features_vector):


    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vScale[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.5):
            q[k] = 0
        elif (summation[k] > 0.5 and summation[k] <= 1):
            q[k] = (summation[k] - 0.5) / (1 - 0.5)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

# OWA + I (vTrain)
def weightsOWA_mostI_vTrain(features_vector):

    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vTrain[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    most_lower = 0.5
    most_upper = 0.6

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= most_lower):
            q[k] = 0
        elif (summation[k] > most_lower and summation[k] < most_upper):
            q[k] = (summation[k] - most_lower) / (most_upper - most_lower)
        elif (summation[k] >= most_upper):
            q[k] = 1

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more75I_vTrain(features_vector):


    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vTrain[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.75):
            q[k] = 0
        elif (summation[k] > 0.75 and summation[k] <= 1):
            q[k] = (summation[k] - 0.75) / (1 - 0.75)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_most_more75_I_vTrain(features_vector):


    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vTrain[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    most_lower = 0.5
    most_upper = 0.6

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if summation[k] < 0.5:
            # Most QL
            if (summation[k] > 0 and summation[k] <= most_lower):
                q[k] = 0
            elif (summation[k] > most_lower and summation[k] < most_upper):
                q[k] = (summation[k] - most_lower) / (most_upper - most_lower)
            elif (summation[k] >= most_upper):
                q[k] = 1
        else:
            # More75 QL
            if (summation[k] > 0 and summation[k] <= 0.75):
                q[k] = 0
            elif (summation[k] > 0.75 and summation[k] <= 1):
                q[k] = (summation[k] - 0.75) / (1 - 0.75)


    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()

def weightsOWA_more50I_vTrain(features_vector):


    ########################################################
    a = features_vector
    # b = vector of sorted features in decreasing order
    b = (-np.sort(-a))

    # Importance values u[j] for 'b':
    # v[i] respectively associated with its feature in 'a'
    u = np.empty([1, dfZscore.shape[1] - 1])
    u = u.flatten()
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] == b[j]:
                u[j] = vTrain[i]

    # Computation of QL x (with the importance no more i/n but SUM(k=1 to j) u[k]/t with t=sum(u)
    t = u.sum()
    summation = np.empty([1, dfZscore.shape[1] - 1])
    summation = summation.flatten()
    for k in range(len(u)):
        if k == 0:
            summation[k] = u[k]/t
        else:
            summation[k] = ((summation[k-1]*t) + u[k]) / t
    ########################################################

    q = np.empty([1, len(features_vector)])
    q = q.flatten()
    for k in range(len(summation)):
        if (summation[k] > 0 and summation[k] <= 0.5):
            q[k] = 0
        elif (summation[k] > 0.5 and summation[k] <= 1):
            q[k] = (summation[k] - 0.5) / (1 - 0.5)

    weights = np.empty([1, len(features_vector)])
    weights = weights.flatten()
    for i in range(len(features_vector)):
        if i == 0:
            weights[i] = q[i] - 0
        elif i == (len(features_vector)-1):
            weights[i] = 1 -  q[i - 1]
        else:
            weights[i] = q[i] - q[i-1]


    return weights.tolist()


# Computation of the aggregation value
def calc_aggr_value(features_vector, weight_vector):
    #print(features_vector)
    features_vector = -np.sort(features_vector)
    value = 0
    for i in range(len(features_vector)):
        #print(weight_vector)
        #print(features_vector[i], '*', weight_vector[i])
        value += features_vector[i] * weight_vector[i]

    return value


# JSON file creation with: features values, weights, OWA value, truth label
def eventsOWA(xData, yData, OWA_method, filename):
    eventsOWA = {}
    for eventIndex in range(xData.shape[0]):
        #print(eventIndex)
        # Sorting the normalized features vectors
        #(-np.sort(-xData[eventIndex])

        OWA_method_str = OWA_method + '(xData[eventIndex])'

        eventsOWA[dfZscore.index[eventIndex]] = {'features': (-np.sort(-xData[eventIndex])).tolist(),
                                               'weights': eval(OWA_method_str),
                                               'OWA_value': calc_aggr_value(np.sort(-xData[eventIndex]),
                                                            eval(OWA_method_str)),
                                               'truth': yData[eventIndex]}
        #if (eventIndex == 8):
            #print(eventsOWA[dfZscore.index[eventIndex]])

    # New pandas DataFrame from the eventsOrdered to sort it by mean in descending order
    dfOWA = pd.DataFrame(eventsOWA)
    #print(dfOWA)
    # Fix the orientation

    #print(dfOWA.loc['age_trailer_ultron-20141023_082640-20141023_092640']['weights'])
    dfOWA = dfOWA.transpose()
    #print(dfOWA.loc['age_trailer_ultron-20141023_082640-20141023_092640']['weights'])

    # Sorting by OWA value in descending order
    #dfOWA = dfOWA.sort_values('OWA_value', ascending=False)
    # Convert the dfOWA to a dict to store it neatly in a json file
    dict_dfOWA = dfOWA.to_dict(orient='index')
    #print(dict_dfOWA)
    #print(dict_dfOWA)
    with open(filename, 'w') as file:
         output = json.dump(dict_dfOWA, file, indent = 4)

    return dfOWA

#quit()



# dfZscore (all events)
x = dfZscore[list(filter(lambda x: x != "truth", dfZscore.columns))]
y = dfZscore["truth"]
xData = x.as_matrix()
yData = y.as_matrix()

# dfTrain
dfTrainOWA = pd.read_json('data/train.json', orient='index')
# To fix error: 'TypeError: Object of type 'int64' is not JSON serializable'
dfTrainOWA = dfTrainOWA.astype(object)
xTrain = dfTrainOWA[list(filter(lambda x: x != "truth", dfTrainOWA.columns))]
yTrain = dfTrainOWA["truth"]
xDataTrain = xTrain.as_matrix()
yDataTrain = yTrain.as_matrix()
# dfTest
dfTestOWA = pd.read_json('data/test.json', orient='index')
# To fix error: 'TypeError: Object of type 'int64' is not JSON serializable'
dfTestOWA = dfTestOWA.astype(object)
xTest = dfTestOWA[list(filter(lambda x: x != "truth", dfTestOWA.columns))]
yTest = dfTestOWA["truth"]
xDataTest = xTest.as_matrix()
yDataTest = yTest.as_matrix()

# CHANGE FILENAME
filename = 'data/zscore_more75.json'
# CHOOSE METHOD
method = 'weightsOWA_more75'

dfOWA = eventsOWA(xData, yData, method, filename)
label = dfOWA['truth'].values.astype(float)
predictionOWA = dfOWA['OWA_value'].values.astype(float)
metrics_calc(label, predictionOWA)