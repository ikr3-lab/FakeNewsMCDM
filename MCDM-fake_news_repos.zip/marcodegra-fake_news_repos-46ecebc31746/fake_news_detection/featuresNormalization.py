import json
import pandas as pd

featuresFile = 'data/credbank_features.json'

df = pd.read_json(featuresFile, orient='index')
# To preserve the order of columns
#df = df[["polarity","mediaCount","verified","truth","density","ages","lifespan","mentionCount","urlCount",
#         "retweetCount","followers","status_count","hashtagCount","objectivity","friends","tweetCount"]]

# To suppress scientific notation for small values
# To fix error: 'TypeError: Object of type 'int64' is not JSON serializable'
df = df.astype(object)


# Convert the features DataFrame to a dict to store it neatly in a new json file
dfOrdDict = df.to_dict('index')
with open('data/ordered_features.json', 'w') as file:
    json.dump(dfOrdDict, file, indent=4)


#print(df.ix[0:5, ['polarity', 'truth']])

# Calculate the max/min value of each feature among all the events
def calculateRange(feature):

    featureMin = df[feature].values[0]
    featureMax = df[feature].values[0]

    for row in range(df.shape[0]):
        if df[feature].values[row] < featureMin:
            featureMin = df[feature].values[row]
        elif df[feature].values[row] > featureMax:
            featureMax = df[feature].values[row]

    #print(feature)
    #print(df[feature].values)
    #print('Min:', featureMin, '\nMax:',  featureMax, '\n')

    return featureMin, featureMax


# Calculate the average mean and standard deviation for each feature among all the events
# def calculateZcore(feature):
#
#     featureMean = df[feature].mean()
#     featureStd = df[feature].std()
#
#     return featureMean, featureStd


# Create a dict of all features range values
featuresRange = {}
for column in df:
    (min, max) = calculateRange(column)
    featuresRange[column] = {'min': min, 'max': max}
#print('\nFeatures ranges = ', featuresRange)

#
# featuresZscore = {}
# for column in df:
#     (mean, std) = calculateZcore(column)
#     featuresZscore[column] = {'mean': mean, 'std': std}


# Store the dict in a json file
with open('data/featuresRange.json', 'w') as file:
    json.dump(featuresRange, file, indent=4)

# # Store the Zscore dict in a json file
# with open('data/featureszScore.json', 'w') as file:
#     json.dump(featuresZscore, file, indent=4)


# Method to normalized a feature value with the statistic normalization formula
def normalize(value, min, max):

    # value = feature value for the event
    # min = feature minimum value among all the events
    # max = feature maximum value among all the events
    valNorm = (value - min) / (max - min)

    return valNorm

# Method to normalized a feature value with the statistic normalization formula
# def normZscore(value, mean, std):
#
#     valNorm = (value - mean) / std
#
#     return valNorm


# New pandas DataFrame with normalized values
dfNorm = df
for row in range(dfNorm.shape[0]):
    for column in dfNorm:
        valueParam = dfNorm[column].values[row]
        minParam = featuresRange[column]['min']
        maxParam = featuresRange[column]['max']
        dfNorm[column].values[row] = normalize(valueParam, minParam, maxParam)

# #New pandas DataFrame with Z-score normalized values
# dfZscore = df
# for row in range(dfZscore.shape[0]):
#     for column in dfZscore:
#         if column == 'truth':
#             continue
#         else:
#             valueParam = dfZscore[column].values[row]
#             meanParam = featuresZscore[column]['mean']
#             stdParam = featuresZscore[column]['std']
#             dfZscore[column].values[row] = normZscore(valueParam, meanParam, stdParam)

#print(dfNorm.index)

# Convert the normalized features DataFrame to a dict to correctly stored it in a json file
dfNormDict = dfNorm.to_dict('index')
with open('data/normalized_ordered_features.json', 'w') as file:
    json.dump(dfNormDict, file, indent=4)


# # Convert the Z-score DataFrame to a dict to correctly store it in a json file
# dfZscoreDict = dfZscore.to_dict('index')
# with open('data/zscore_features.json', 'w') as file:
#     json.dump(dfZscoreDict, file, indent=4)

