import numpy as np
import pandas as pd
# Importing of DataFrame with the 15 features (all except of 'truth')
from correlation_matrix import x as dfNorm15, dfCorr
from newOWA_aggregation import v
from newOWA_aggregation import vTrain
from rocOWA import metrics_calc
from newOWA_aggregation import xData, yData, xDataTrain, yDataTrain, xDataTest, yDataTest
from featuresNormalization import dfNorm
from golbeckTests import dfTrain, dfTest
import json
from sklearn.metrics import *


# Defining of all singleton importance values I_i
def calc_importance(imporV, formula):
    I_i = np.empty([1, dfNorm15.shape[1]])
    I_i = I_i.flatten()
    for i in range(dfNorm15.shape[1]):
        I_i[i] = eval(formula)

    return I_i

# Defining of all interaction indexes I_ij
def calc_interaction(formula_plus, formula_minus):
    # Matrix of I_ij[i,j]
    # I_ij shape = dfNorm15.shape[1] rows and dfNorm15.shape[1] cols = 15x15 = (0,14)x(0,14)
    I_ij = np.zeros([dfNorm15.shape[1], dfNorm15.shape[1]])

    # Calculation of I_ij[i,j] values
    for i in range(dfNorm15.shape[1]):
        for j in range(dfNorm15.shape[1]):
            if i != j:
                if (dfCorr.iloc[i,j] > 0):
                    I_ij[i,j] = eval(formula_plus)
                elif (dfCorr.iloc[i,j] < 0):
                    I_ij[i, j] = eval(formula_minus)
            else:
                I_ij[i,j] = None

    # Assign the same value to the simmetric half of I[i,j]
    for i in range(I_ij.shape[0]):
        for j in range(I_ij.shape[1]):
            if j<i:
                I_ij[i, j] = I_ij[j, i]

    return I_ij

#################################################################################

# Importance/Shapley and Interaction indexes constraints satisfaction

# SUM(i=1 to n) I[i] = 1
def sumI_i(impor_i):
    summation = 0
    for i in range(impor_i.shape[0]):
        #print(impor_i[i])
        summation += impor_i[i]

    return round(summation, 2)

# -1 <= I[i,j] <= 1
def rangeI_ij(inter_ij):
    count_no = 0
    for i in range(inter_ij.shape[0]):
        for j in range(inter_ij.shape[1]):
            if i != j:
                if inter_ij[i,j] >= -1 and inter_ij[i,j] <= 1:
                    #print(inter_ij[i,j])
                    pass
                else:
                    count_no += 1
                    #print(inter_ij[i,j])
    if count_no == 0:
        #out = 'OK! All I[i,j] in range [-1,1]'
        return True
    else:
        #out = 'NOT all I[i,j] in range [-1,1]!!!'
        return False

    #return out

def choquet_property(impor_i, inter_ij):
    count_no = 0
    for i in range(inter_ij.shape[0]):
        summ = 0
        for j in range(inter_ij.shape[1]):
            if i != j:
                summ += abs(inter_ij[i,j])
                #print('\n',abs(inter_ij[i,j]), '+')
        #print(i+1, summ)

        formula = round((impor_i[i] - (0.5 * summ)), 3)
        #print(impor_i[i+1], '-0.5*', summ)
        #print(i+1, 'property', formula)
        if formula >= 0:
            pass
        else:
            count_no += 1

    if count_no == 0:
        #print("OK! Property satisfied")
        return True
    else:
        #print("Property NOT satisfied!!!")
        return False

    #return out

#################################################################################

# 2-additive Choquet Integral computation
def calc_choquet(f_val, impor_i, inter_ij):
    sum_interPos = 0
    sum_interNeg = 0
    for i in range(inter_ij.shape[0]):
        for j in range(inter_ij.shape[1]):
            if i != j:
                if inter_ij[i,j] > 0:
                    sum_interPos += min(f_val[i], f_val[j]) * (inter_ij[i,j])
                    #print('I[', i+1, ',', j+1, ']', inter_ij[i,j], 'fval', i+1, f_val[i], 'fval', j+1, f_val[j])
                elif inter_ij[i,j] < 0:
                    sum_interNeg += max(f_val[i], f_val[j]) * abs(inter_ij[i,j])
                    #print('I[', i + 1, ',', j + 1, ']', inter_ij[i, j], 'fval', i + 1, f_val[i], 'fval', j + 1, f_val[j])
        #print('SUM', sum_interPos)
        #print('SUM', sum_interNeg)

    last_part = 0
    for i in range(inter_ij.shape[0]):
        summ = 0
        for j in range(inter_ij.shape[1]):
            if i != j:
                summ += abs(inter_ij[i,j])
                #print('\n',abs(inter_ij[i,j]), '+')
        #print('\n', i+1, summ)

        formula = (impor_i[i] - (0.5 * summ))
        #print('vi', i+1, impor_i[i+1])
        #print('formula choq int', i, formula)
        last_part += f_val[i] * formula
        #print('last part', last_part)


    result = (sum_interPos + sum_interNeg + last_part)
    #print(result)
    return result

#JSON file creation with: features values, Choquet-Integral value, truth label
def eventsChoquet(xData, yData):
    eventsChoquet = {}
    for eventIndex in range(xData.shape[0]):
        eventsChoquet[dfNorm.index[eventIndex]] = {'features': xData[eventIndex].tolist(),
                                                   'Choquet-Integral value': calc_choquet(xData[eventIndex],
                                                                                            I_i, I_ij),
                                                   'truth': yData[eventIndex]}

    # New pandas DataFrame from the eventsOrdered to sort it by mean in descending order
    dfChoquet = pd.DataFrame(eventsChoquet)
    # Fix the orientation
    dfChoquet = dfChoquet.transpose()
    dict_dfChoquet = dfChoquet.to_dict(orient='index')
    filename = 'data/eventsChoquetIntegral.json'
    with open(filename, 'w') as file:
        output = json.dump(dict_dfChoquet, file, indent = 4)

    return dfChoquet

def choquet_roc_calc(label, prediction):

    fpr, tpr, thresholds = roc_curve(label, prediction)
    roc_auc = auc(fpr, tpr)
    # plt.plot(fpr, tpr, lw=1, label='ROC (area = %0.2f)' % (roc_auc))
    #
    # plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Luck')
    #
    # plt.xlim([-0.05, 1.05])
    # plt.ylim([-0.05, 1.05])
    # plt.grid()
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.title('Receiver Operating Characteristic')
    # plt.legend(loc="lower right")
    #
    # plt.savefig("data/rocauc.pdf", format="pdf")
    # plt.show()

    optimal_idx = np.argmax(tpr - fpr)
    optimal_threshold = thresholds[optimal_idx]
    print('Optimal ROC-AUC threshold:', round(optimal_threshold, 4))

    # Create a binary prediction vector based on OWA optimal threshold
    prediction_label = []
    for i in range(len(prediction)):
        if (prediction[i] >= optimal_threshold):
            prediction_label.append(1)
        else:
            prediction_label.append(0)

    accuracy = accuracy_score(label, prediction_label)
    precision = precision_score(label, prediction_label)
    recall = recall_score(label, prediction_label)
    f1 = f1_score(label, prediction_label)

    #confusion_matrix = sklearn.metrics.confusion_matrix(label, prediction_label)
    #print('\nTP:', confusion_matrix[1][1], 'TN:', confusion_matrix[0][0],
         # '\nFP:', confusion_matrix[0][1], 'FN:', confusion_matrix[1][0])

    print('\nACCURACY:', round(accuracy, 2))
    print('PRECISION:', round(precision, 2))
    print('RECALL:', round(recall, 2))
    print('F1-SCORE:', round(f1, 2))

    return round(roc_auc, 2)


#--------------------------------------------------------------------------------------
# Tests with I_i-I_ij from R Kappalab

#RUN
# shapleyR = np.empty([1, dfNorm15.shape[1]])
# shapleyR = shapleyR.flatten()
# shapleyR[0]= 0.473106763; shapleyR[1]= 0.005099635; shapleyR[2]= 0.006520065; shapleyR[3]= 0.004937881
# shapleyR[4]= 0.004988512; shapleyR[5]= 0.026507986; shapleyR[6]= 0.473747349; shapleyR[7]= 0.005091809
# shapleyR[8]= 0; shapleyR[9]= 0; shapleyR[10]= 0; shapleyR[11]= 0; shapleyR[12]= 0; shapleyR[13]= 0; shapleyR[14]= 0
# formula = 'shapleyR[i]'
# I_i = calc_importance(shapleyR, formula)
# #print(I_i)
#
# #formula_plus = '(dfCorr.iloc[i,j] * I_i[i])/15'
# #formula_minus = '(dfCorr.iloc[i,j] * I_i[i])/15'
# #I_ij = calc_interaction(formula_plus, formula_minus)
# I_ij = np.genfromtxt("/Users/marcodegra/Documents/thesis_repo/fake_news_repos/R/training_set/ls4e8f_inter_indicesR.csv", delimiter = ",")
#
# #cols = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
# #df_I_ij = pd.DataFrame(I_ij, columns=cols, index=cols)
# #print(df_I_ij)
#
# print('Summation of all Importance values =', sumI_i(I_i))
# print(rangeI_ij(I_ij))
# print(choquet_property(I_i, I_ij), '\n')
#
# dfNorm = dfNorm[["verified", "friends", "objectivity", "urlCount", "status_count", "polarity", "retweetCount",
#                          "tweetCount", "hashtagCount", "followers", "lifespan", "mentionCount", "ages", "density",
#                          "mediaCount", "truth"]]
# x = dfNorm[list(filter(lambda x: x != "truth", dfNorm.columns))]
# y = dfNorm["truth"]
# xData = x.as_matrix()
# yData = y.as_matrix()
# #print(yData)

#
# dfChoquet = eventsChoquet()
# label = dfChoquet['truth'].values.astype(float)
# predictionChoquet = dfChoquet['Choquet-Integral value'].values.astype(float)
# metrics_calc(label, predictionChoquet)
# #--------------------------------------------------------------------------------------
# quit()


#----------------------------------------------------------------------------------

#  R
# Ordering features based on: v for input in Kappalab
#dfNorm = dfNorm[["verified", "friends", "objectivity", "urlCount", "status_count", "polarity", "retweetCount",
                         #"tweetCount", "hashtagCount", "followers", "lifespan", "mentionCount", "ages", "density",
                         #"mediaCount"]]

# Ordering features based on: vTrain for input in Kappalab ('truth' at the end)
dfR_vTrain_training = dfTrain[["ages", "friends", "mediaCount", "density", "lifespan", "tweetCount",
                         "objectivity", "polarity", "retweetCount", "mentionCount", "verified", "hashtagCount", "followers",
                         "status_count", "urlCount", "truth"]]
dfR_vTrain_testing = dfTest[["ages", "friends", "mediaCount", "density", "lifespan", "tweetCount",
                         "objectivity", "polarity", "retweetCount", "mentionCount", "verified", "hashtagCount", "followers",
                         "status_count", "urlCount", "truth"]]
# Convert the features DataFrame to a dict to stored it neatly in a new json file for R
dictR_vTrain_training = dfR_vTrain_training.to_dict('index')
with open('data/dfR_vTrain_training.json', 'w') as file:
    json.dump(dictR_vTrain_training, file, indent=4)
# Convert the features DataFrame to a dict to stored it neatly in a new json file for R
dictR_vTrain_testing = dfR_vTrain_testing.to_dict('index')
with open('data/dfR_vTrain_testing.json', 'w') as file:
    json.dump(dictR_vTrain_testing, file, indent=4)

# R



# formula = 'round(vTrain[i]/sum(vTrain), 2)'
# I_i = calc_importance(vTrain, formula)
# #print(I_i)

# # Iterations of 0.01
# I_ij = np.zeros([dfNorm15.shape[1], dfNorm15.shape[1]])
#
# # Initialization of I_ij[i,j] values with dfCorr[i,j]/0s values
# for i in range(dfNorm15.shape[1]):
#     for j in range(dfNorm15.shape[1]):
#         if i != j:
#             if (dfCorr.iloc[i,j] > 0):
#                 I_ij[i,j] = 0
#             elif (dfCorr.iloc[i,j] < 0):
#                 I_ij[i,j] = 0
#         else:
#             I_ij[i,j] = None
# # Assign the same value to the simmetric half of I[i,j]
# for i in range(I_ij.shape[0]):
#     for j in range(I_ij.shape[1]):
#         if j<i:
#             I_ij[i, j] = I_ij[j, i]
#
# if choquet_property(I_i, I_ij): # and rangeI_ij(I_ij):
#     dfChoquet = eventsChoquet(xData, yData)
#     label = dfChoquet['truth'].values.astype(float)
#     predictionChoquet = dfChoquet['Choquet-Integral value'].values.astype(float)
#     #print(sumI_i(I_i))
#     #print(rangeI_ij(I_ij))
#     #print(choquet_property(I_i, I_ij))
#     #print(choquet_property(I_i, I_ij))
#     print('ROC:', choquet_roc_calc(label, predictionChoquet), '\n')
# #print(I_ij)
#
#
# const = 0.0001
# def iteration_Iij():
#     for i in range(I_ij.shape[0]):
#         for j in range(I_ij.shape[1]):
#             if  I_ij[i,j] >= 1:
#                 continue
#             elif I_ij[i,j] <= -1:
#                 continue
#             else:
#                 if i != j:
#                     if (dfCorr.iloc[i,j] >= 0):
#                         I_ij[i,j] += const
#                     elif (dfCorr.iloc[i,j] < 0):
#                         I_ij[i,j] -= const
#                 else:
#                     I_ij[i,j] = None
#     # Assign the same value to the simmetric half of I[i,j]
#     for i in range(I_ij.shape[0]):
#         for j in range(I_ij.shape[1]):
#             if j<i:
#                 I_ij[i, j] = I_ij[j, i]
#
#     print('iteration number:', iteration)
#     if choquet_property(I_i, I_ij):  # and rangeI_ij(I_ij):
#         dfChoquet = eventsChoquet(xData, yData)
#         label = dfChoquet['truth'].values.astype(float)
#         predictionChoquet = dfChoquet['Choquet-Integral value'].values.astype(float)
#         # print(sumI_i(I_i))
#         # print(rangeI_ij(I_ij))
#         # print(choquet_property(I_i, I_ij))
#         # print(choquet_property(I_i, I_ij))
#         print('ROC:', choquet_roc_calc(label, predictionChoquet), '\n')
#     #print(I_ij)
#
#
# count = 1/const
# iteration = 0
# while (count > 0):
#     iteration_Iij()
#     count -= 1
#     iteration += 1
#     #print(I_ij, '\n')
# print(I_ij)

#--------------------------------------------------------------------------------------



