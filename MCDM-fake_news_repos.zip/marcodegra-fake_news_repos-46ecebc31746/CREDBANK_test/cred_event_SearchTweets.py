import pandas as pd
import math

inputFile = 'data/4cred_event_SearchTweets.data'
outputFile = 'data/topics_tweetCount.tsv'

# dataframe creation with only 'topic_terms' and 'tweet_count' columns
# df = pd.read_csv(inputFile, sep='\t', usecols=['topic_terms', 'tweet_count'])

# df.loc[:, ['topic_terms', 'tweet_count']]

# write dataframe in a file
#df.to_csv(outputFile, sep='\t')

newDf = pd.read_csv(outputFile, sep='\t')
#print(newDf.loc[4, ['tweet_count']]);

print("AVERAGE tweet count for all", newDf.shape[0]-1, "events =",
      math.trunc(newDf['tweet_count'].mean()));

print("TOTAL tweet count for all", newDf.shape[0]-1, "events =",
      newDf['tweet_count'].sum());
